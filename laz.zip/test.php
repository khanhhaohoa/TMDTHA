<?php
include 'class/func.php';
$a = $mysql->get('account');

$token = $a[0]['access_token'];
echo $token;
get_seller_laz('VN1XRBRL');
get_order_laz($token, 'pending');