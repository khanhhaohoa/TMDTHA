<?php
include 'header.php';

//include 'client/product/add2.php';
include 'client/product/add4.php';


include 'footer.php';