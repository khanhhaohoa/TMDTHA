<?php
include "../class/func.php";
$d = last30daysy();
get_seller_laz('VN1XRBRL');
for($i=0;$i<count($d);$i++){
	$res = get_product_laz('VN1XRBRL',$d[$i].'T00:00:00+0800',time.'T00:00:00+0800');
	$file = 'log_get.txt';
				// Open the file to get existing content
	$current = file_get_contents($file);
				// Append a new person to the file
	$current .= "\n".hatime."|".$res['total']."|".count($res['sql_success'])."|".count($res['sql_update'])."|".count($res['sql_fail'])."|".$d[$i]."|".time;

	echo "\n".hatime."|".$res['total']."|".count($res['sql_success'])."|".count($res['sql_update'])."|".count($res['sql_fail'])."|".$d[$i]."|".time;
				// Write the contents back to the file
	file_put_contents($file, $current);
}
