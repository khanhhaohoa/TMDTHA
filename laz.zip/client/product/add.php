<div id="here">
<?php
set_time_limit(0);
include "class/func.php";
$data  = $mysql->get('product');
echo 'Total: '.count($data).'<br />';
$html = '';
for($i=0;$i<count($data);$i++){
    $html .= '<tr class="gradeA odd" role="row" id="row'.$i.'">
    <td id="id'.$i.'">'.$mini[0]['child_id_2'].'</td>
    <td id="name'.$i.'">'.$data[$i]['name'].'</td>
    <td id="category'.$i.'">'.$c.' -> '.$b.' -> '.$a.'</td>
    <td id="shopee'.$i.'">'.$data[$i]['shopee_category'].'</td>
    <td>
    <a href="#" id="edit_button'.$i.'" class="edit" onclick="edit_row('.$i.')"><i class="fa fa-pencil"></i></a>
    <a href="#" id="save_button'.$i.'" class="save" onclick="save_row('.$i.')"><i class="fa fa-save"></i></a>
    </td>
    </tr>';
}
?>
    <div class="col-sm-12">
        <div class="card-box">
            <div class="row">
                <div class="col-sm-6">
                    <div class="m-b-30">
                        <button id="addToTable" class="btn btn-success waves-effect waves-light">Thêm Sản Phẩm <i class="mdi mdi-plus-circle-outline"></i></button>
                    </div>
                </div>
            </div>

            <div id="datatable-editable_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4 no-footer">
                <div class="row">
                    <div class="col-sm-12">
                        <table class="table table-striped add-edit-table dataTable no-footer" id="datatable-editable" role="grid" aria-describedby="datatable-editable_info">
                            <thead>
                                <tr role="row">
                                    <th class="sorting" tabindex="0" aria-controls="datatable-editable" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Rendering engine: activate to sort column descending" style="width: 327px;">Rendering engine</th>
                                    <th class="sorting" tabindex="0" aria-controls="datatable-editable" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending" style="width: 418px;">Browser</th>
                                    <th class="sorting" tabindex="0" aria-controls="datatable-editable" rowspan="1" colspan="1" aria-label="Platform(s): activate to sort column ascending" style="width: 391px;">Platform(s)</th>
                                    <th class="sorting_disabled" rowspan="1" colspan="1" aria-label="Actions" style="width: 255px;">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="gradeA odd" role="row">
                                    <td>Gecko</td>
                                    <td>Firefox 1.0</td>
                                    <td>Win 98+ / OSX.2+</td>
                                    <td class="actions">
                                        <a href="#" id="edit_button'.$i.'" onclick="edit_row('.$i.')" class="on-default edit-row" data-toggle="tooltip" data-placement="top" title=""><i class="fa fa-pencil"></i></a>

                                        <a href="#" class="on-default remove-row" data-toggle="tooltip" data-placement="top" title="" ><i class="fa fa-trash-o"></i></a>

                                        <a href="#" id="save_button'.$i.'" onclick="save_row('.$i.')" class="hidden on-editing save-row" data-toggle="tooltip" data-placement="top" title="" ><i class="fa fa-save"></i></a>

                                        <a href="#" class="hidden on-editing cancel-row" data-toggle="tooltip" data-placement="top" title="" ><i class="fa fa-times"></i></a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end: page -->
<!-- MODAL -->
        <div id="dialog" class="modal-block mfp-hide">
            <section class="card-box">
                <header class="panel-heading">
                    <h4 class="mt-0">Are you sure?</h4>
                </header>
                <div class="panel-body">
                    <div class="modal-wrapper">
                        <div class="modal-text">
                            <p>Are you sure that you want to delete this row?</p>
                        </div>
                    </div>

                    <div class="row m-t-20">
                        <div class="col-md-12 text-right">
                            <button id="dialogConfirm" class="btn btn-primary waves-effect waves-light">Confirm</button>
                            <button id="dialogCancel" class="btn btn-secondary waves-effect">Cancel</button>
                        </div>
                    </div>
                </div>

            </section>
        </div>
        <!-- end Modal -->

        <script type="text/javascript">
function edit_row(no)
{
 document.getElementById("edit_button"+no).style.display="none";
 document.getElementById("save_button"+no).style.display="block";
  
 var name=document.getElementById("name"+no);
 var country=document.getElementById("category"+no);
 var age=document.getElementById("shopee"+no);
  
 var name_data=name.innerHTML;
 var country_data=country.innerHTML;
 var age_data=age.innerHTML;
  
 //name.innerHTML="<input type='text' id='name_text"+no+"' value='"+name_data+"'>";
 //country.innerHTML="<input type='text' id='country_text"+no+"' value='"+country_data+"'>";
 age.innerHTML="<input type='text' id='age_text"+no+"' value='"+age_data+"'>";
}

function save_row(no)
{
 var id=document.getElementById("id"+no).innerText;
 //var name_val=document.getElementById("name_text"+no).value;
 //var country_val=document.getElementById("country_text"+no).value;
 var age_val=document.getElementById("age_text"+no).value;
 var xhttp = new XMLHttpRequest();
 console.log(id);
 console.log(age_val);
 xhttp.open("GET", "update.php?id=" + id + "&shopee=" + age_val, true);
 xhttp.send();
 //document.getElementById("name"+no).innerHTML=name_val;
 //document.getElementById("category"+no).innerHTML=country_val;
 document.getElementById("shopee"+no).innerHTML=age_val;

 document.getElementById("edit_button"+no).style.display="block";
 document.getElementById("save_button"+no).style.display="none";
 document.getElementById("row"+no+"").outerHTML="";
 location.reload();
}

function delete_row(no)
{
 document.getElementById("row"+no+"").outerHTML="";
}

function add_row()
{
 var new_name=document.getElementById("new_name").value;
 var new_country=document.getElementById("new_country").value;
 var new_age=document.getElementById("new_age").value;
  
 var table=document.getElementById("data_table");
 var table_len=(table.rows.length)-1;
 var row = table.insertRow(table_len).outerHTML="<tr id='row"+table_len+"'><td id='name_row"+table_len+"'>"+new_name+"</td><td id='country_row"+table_len+"'>"+new_country+"</td><td id='age_row"+table_len+"'>"+new_age+"</td><td><input type='button' id='edit_button"+table_len+"' value='Edit' class='edit' onclick='edit_row("+table_len+")'> <input type='button' id='save_button"+table_len+"' value='Save' class='save' onclick='save_row("+table_len+")'> <input type='button' value='Delete' class='delete' onclick='delete_row("+table_len+")'></td></tr>";

 document.getElementById("new_name").value="";
 document.getElementById("new_country").value="";
 document.getElementById("new_age").value="";
}
</script>